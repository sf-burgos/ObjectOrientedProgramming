public class Replicate{
	public Replicate{
	
	}

}