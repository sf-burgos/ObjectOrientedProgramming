package aplicacion;

import java.io.Serializable;

public class Mimo extends Maquina implements Serializable {

	public Mimo(int x, int y) {
		super(x, y);
	}

}
