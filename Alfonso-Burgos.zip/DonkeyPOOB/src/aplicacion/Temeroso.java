package aplicacion;

import java.io.Serializable;

public class Temeroso extends Maquina implements Serializable {

	public Temeroso(int x, int y) {
		super(x, y);
		// TODO Auto-generated constructor stub
	}
	public int tipoMaquina() {
		return 0;
	}

}
