package aplicacion;

import java.io.Serializable;

public class Segmentada extends Escalera implements Serializable {

}
