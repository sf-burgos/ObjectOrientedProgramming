package aplicacion;

import java.io.Serializable;

public class Completa extends Escalera implements Serializable{

}
