package aplicacion;

import java.io.Serializable;

public class Nivel implements Serializable {

}
